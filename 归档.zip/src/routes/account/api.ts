import { _axios_tx } from "../../config/axios"

export const getOpenId = (data) => {
    return _axios_tx.get(`/sns/oauth2/access_token?appid=${data?.appid}&secret=${data?.secret}&code=${data?.js_code}&grant_type=authorization_code`)
}