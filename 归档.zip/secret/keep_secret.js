"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
	hapi: {
		port: 5009,
		ip: "0.0.0.0", // localhost 会限定host ip
	},
	mongodb: {
		//connectionString: "mongodb://lucas:lucas123456@175.27.159.24:27017/emp?authSource=admin",
		//connectionString: "mongodb://hong:PASSWORD@localhost:27017/emp",
		// connectionString: "mongodb://127.0.0.1:27017/emp",
		connectionString: "mongodb://root:nxHQMTvzCXcsrvaZ@172.16.70.9:27017/emp?authSource=admin"
	},
	redis: {
		//connectionString: "redis://alice:foobared@awesome.redis.server:6380",
		// connectionString: "redis://127.0.0.1:6379",
		connectionString: "redis://172.16.70.9:6380",
		password: "ddipMzbaHtEw7PZK"
	},
	crypto: {
		privateKey: "YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoxMjM0NTY=",
		tokenExpiry: 60, //in seconds
	},
	email: {
		test: false,
		smtp: {
			host: "smtp.exmail.qq.com",
			port: 465,
			secure: true,
			username: "mtc@xihuanwu.com",
			password: "JgMXvH9obubvahX5",
			from: "'MTC Admin' mtc@xihuanwu.com",
		},
		/*
        smtp: {
          host: "smtp.qq.com",
          port: 465,
          secure: true,
          username: "colobodocs",
          password: "cxfaqmreqpmqchhh",
          from: "'Admin' colobodocs@qq.com",
        },
        smtp: {
          host: "smtp-pulse.com",
          port: 465,
          secure: true,
          username: "liukehong@gmail.com",
          password: "i9GbfL7FCR",
          from: "Lucas Liu",
        },
        */
	},
	verify: {
		email: {
			notwithin: 60,
			verifyin: 15 * 60,
		},
	},
	admin: "3506345550@qq.com",
	ap: "wdGSjbj@2022",
};
//# sourceMappingURL=keep_secret.js.map
